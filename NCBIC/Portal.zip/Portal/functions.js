<script type="text/javascript">
function submitform()
{
  document.myform.submit();
}
</script>